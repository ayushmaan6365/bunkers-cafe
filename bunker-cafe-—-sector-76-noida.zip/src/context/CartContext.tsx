import React, { createContext, useContext, useState, useEffect } from 'react';
import { MenuItem, Coupon, AVAILABLE_COUPONS, BUSINESS_FACTS } from '../data/cafeData';

export interface CartItem {
  menuItem: MenuItem;
  quantity: number;
  instructions?: string;
}

export type OrderType = 'delivery' | 'takeaway' | 'dinein';

export interface PlacedOrder {
  orderId: string;
  items: CartItem[];
  orderType: OrderType;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  cookingNotes: string;
  itemTotal: number;
  deliveryFee: number;
  packagingFee: number;
  tax: number;
  discount: number;
  appliedCoupon: Coupon | null;
  grandTotal: number;
  timestamp: string;
  status: 'confirmed' | 'preparing' | 'out_for_delivery' | 'ready_for_pickup';
}

interface CartContextType {
  cart: CartItem[];
  addToCart: (item: MenuItem) => void;
  removeFromCart: (itemId: string) => void;
  updateQuantity: (itemId: string, delta: number) => void;
  clearCart: () => void;
  totalItemCount: number;
  itemTotal: number;
  deliveryFee: number;
  packagingFee: number;
  tax: number;
  discount: number;
  grandTotal: number;
  appliedCoupon: Coupon | null;
  applyCoupon: (code: string) => { success: boolean; message: string };
  removeCoupon: () => void;
  orderType: OrderType;
  setOrderType: (type: OrderType) => void;
  isCartDrawerOpen: boolean;
  setIsCartDrawerOpen: (open: boolean) => void;
  lastPlacedOrder: PlacedOrder | null;
  placeOrder: (details: {
    customerName: string;
    customerPhone: string;
    customerAddress: string;
    cookingNotes: string;
    paymentMethod: string;
  }) => PlacedOrder;
  toastMessage: string | null;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('bunker_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [orderType, setOrderType] = useState<OrderType>('delivery');
  const [isCartDrawerOpen, setIsCartDrawerOpen] = useState(false);
  const [lastPlacedOrder, setLastPlacedOrder] = useState<PlacedOrder | null>(() => {
    try {
      const saved = localStorage.getItem('bunker_last_order');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('bunker_cart', JSON.stringify(cart));
    } catch {
      // ignore
    }
  }, [cart]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 2500);
  };

  const addToCart = (item: MenuItem) => {
    setCart((prev) => {
      const existing = prev.find((ci) => ci.menuItem.id === item.id);
      if (existing) {
        return prev.map((ci) =>
          ci.menuItem.id === item.id ? { ...ci, quantity: ci.quantity + 1 } : ci
        );
      }
      return [...prev, { menuItem: item, quantity: 1 }];
    });
    showToast(`Added ${item.name} to order`);
  };

  const removeFromCart = (itemId: string) => {
    setCart((prev) => prev.filter((ci) => ci.menuItem.id !== itemId));
  };

  const updateQuantity = (itemId: string, delta: number) => {
    setCart((prev) => {
      return prev
        .map((ci) => {
          if (ci.menuItem.id === itemId) {
            const newQty = ci.quantity + delta;
            return newQty > 0 ? { ...ci, quantity: newQty } : null;
          }
          return ci;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  const clearCart = () => {
    setCart([]);
    setAppliedCoupon(null);
  };

  const totalItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const itemTotal = cart.reduce((sum, item) => sum + item.menuItem.price * item.quantity, 0);

  const deliveryFee = orderType === 'delivery' ? (itemTotal >= BUSINESS_FACTS.minOrderForFreeDelivery ? 0 : 35) : 0;
  const packagingFee = orderType === 'delivery' || orderType === 'takeaway' ? 20 : 0;
  const tax = Math.round(itemTotal * 0.05); // 5% GST standard for restaurant food

  let discount = 0;
  if (appliedCoupon) {
    if (itemTotal >= appliedCoupon.minOrder) {
      if (appliedCoupon.type === 'flat') {
        discount = appliedCoupon.discount;
      } else {
        discount = Math.min(Math.round((itemTotal * appliedCoupon.discount) / 100), 100);
      }
    } else {
      // Order fell below coupon minOrder
      discount = 0;
    }
  }

  const grandTotal = Math.max(0, itemTotal + deliveryFee + packagingFee + tax - discount);

  const applyCoupon = (code: string) => {
    const found = AVAILABLE_COUPONS.find((c) => c.code.toUpperCase() === code.trim().toUpperCase());
    if (!found) {
      return { success: false, message: 'Invalid coupon code.' };
    }
    if (itemTotal < found.minOrder) {
      return {
        success: false,
        message: `Min order for ${found.code} is ₹${found.minOrder}. Add items worth ₹${found.minOrder - itemTotal} more!`
      };
    }
    setAppliedCoupon(found);
    showToast(`Coupon ${found.code} applied! Saved ₹${found.type === 'flat' ? found.discount : Math.min(Math.round((itemTotal * found.discount) / 100), 100)}`);
    return { success: true, message: `Coupon ${found.code} applied successfully!` };
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
  };

  const placeOrder = (details: {
    customerName: string;
    customerPhone: string;
    customerAddress: string;
    cookingNotes: string;
    paymentMethod: string;
  }) => {
    const orderNumber = Math.floor(1000 + Math.random() * 9000);
    const orderId = `BC-${orderNumber}`;
    const newOrder: PlacedOrder = {
      orderId,
      items: [...cart],
      orderType,
      customerName: details.customerName,
      customerPhone: details.customerPhone,
      customerAddress: details.customerAddress,
      cookingNotes: details.cookingNotes,
      itemTotal,
      deliveryFee,
      packagingFee,
      tax,
      discount,
      appliedCoupon,
      grandTotal,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'confirmed'
    };

    setLastPlacedOrder(newOrder);
    try {
      localStorage.setItem('bunker_last_order', JSON.stringify(newOrder));
    } catch {
      // ignore
    }

    clearCart();
    setIsCartDrawerOpen(false);
    return newOrder;
  };

  return (
    <CartContext.Provider
      value={{
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        totalItemCount,
        itemTotal,
        deliveryFee,
        packagingFee,
        tax,
        discount,
        grandTotal,
        appliedCoupon,
        applyCoupon,
        removeCoupon,
        orderType,
        setOrderType,
        isCartDrawerOpen,
        setIsCartDrawerOpen,
        lastPlacedOrder,
        placeOrder,
        toastMessage
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};

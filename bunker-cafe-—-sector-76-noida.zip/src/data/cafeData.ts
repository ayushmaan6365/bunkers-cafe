export interface MenuItem {
  id: string;
  name: string;
  price: number;
  priceDisplay: string;
  category: string;
  description: string;
  isVeg: boolean | null; // true: veg, false: non-veg, null: both/customizable
  image: string;
  rating?: string;
  votes?: number;
  bestseller?: boolean;
  serves?: string;
  customizable?: boolean;
}

export interface MenuCategory {
  id: string;
  name: string;
  items: MenuItem[];
}

export interface Review {
  author: string;
  rating: number;
  comment: string;
  date: string;
  helpfulCount: number;
}

export interface Coupon {
  code: string;
  discount: number; // in percentage or flat
  type: 'percent' | 'flat';
  minOrder: number;
  description: string;
}

export const BUSINESS_FACTS = {
  name: 'Bunker Cafe',
  subname: 'Sector 76’s cozy hangout',
  address: 'Shop 2 & 3, Lower Ground Floor, Commercial Complex, Street 76, Sector 76, Noida 201303',
  locality: 'Sector 76, Noida',
  phone: '+91 88609 82571',
  phoneRaw: '+918860982571',
  whatsappUrl: 'https://wa.me/918860982571',
  hours: '11:30 AM – 12:00 Midnight (Open Daily)',
  isOpen: true,
  deliveryTime: '25-35 mins',
  deliveryFee: 0, // Free delivery promo
  minOrderForFreeDelivery: 199,
  priceForTwo: '₹450 for two',
  googleRating: 4.6,
  googleReviewCount: 102,
  diningRating: 4.4,
  cuisines: ['Biryani', 'Kebabs & Tandoor', 'Chinese', 'Burgers', 'Pizza', 'Pasta', 'Momos', 'Beverages', 'Desserts'],
  mapEmbedUrl: 'https://www.google.com/maps?q=Bunker%20Cafe,Street%2076,%20Sector%2076,%20Noida%20201303&output=embed',
  directionsUrl: 'https://www.google.com/maps/search/?api=1&query=Bunker+Cafe+Sector+76+Noida'
};

export const AVAILABLE_COUPONS: Coupon[] = [
  {
    code: 'BUNKER50',
    type: 'flat',
    discount: 50,
    minOrder: 299,
    description: 'Flat ₹50 OFF on orders above ₹299'
  },
  {
    code: 'WELCOME50',
    type: 'percent',
    discount: 50,
    minOrder: 199,
    description: '50% OFF up to ₹100 on first order'
  },
  {
    code: 'FREEDEL',
    type: 'flat',
    discount: 29,
    minOrder: 199,
    description: 'FREE Delivery on orders above ₹199'
  }
];

export const ALL_MENU_ITEMS: MenuItem[] = [
  // Biryani
  {
    id: 'biryani-matka',
    name: 'Hyderabadi Matka Biryani (Chicken)',
    price: 249,
    priceDisplay: '₹249 onwards',
    category: 'biryani',
    description: 'Authentic slow-cooked spiced basmati rice and succulent chicken pieces sealed inside an earthen clay matka with caramelized onions and saffron.',
    isVeg: false,
    image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=700&q=80',
    rating: '4.9',
    votes: 84,
    bestseller: true,
    serves: 'Serves 1-2',
    customizable: true
  },
  {
    id: 'biryani-chicken-dum',
    name: 'Chicken Dum Biryani',
    price: 229,
    priceDisplay: '₹229 onwards',
    category: 'biryani',
    description: 'Fragrant aged long-grain basmati layered with tender chicken chunks, slow dum cooked in traditional copper vessel with aromatic potli spices.',
    isVeg: false,
    image: 'https://images.unsplash.com/photo-1633945274405-b6c8069047b0?auto=format&fit=crop&w=700&q=80',
    rating: '4.7',
    votes: 56,
    bestseller: true,
    serves: 'Serves 1-2'
  },
  {
    id: 'biryani-veg-keema',
    name: 'Veg Keema Biryani',
    price: 199,
    priceDisplay: '₹199 onwards',
    category: 'biryani',
    description: 'Customer favourite! Spiced soya & vegetable keema cooked with aromatic herbs and long-grain basmati rice. Bursting with flavors.',
    isVeg: true,
    image: 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=700&q=80',
    rating: '4.8',
    votes: 49,
    bestseller: true,
    serves: 'Serves 1'
  },
  {
    id: 'biryani-egg',
    name: 'Egg Biryani',
    price: 179,
    priceDisplay: '₹179 onwards',
    category: 'biryani',
    description: 'Golden shallow-fried boiled eggs steeped in spiced biryani gravy and layered with aromatic flavored basmati.',
    isVeg: false,
    image: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=700&q=80',
    rating: '4.5',
    votes: 28,
    serves: 'Serves 1'
  },

  // Kebabs & Tandoor
  {
    id: 'kebab-seekh',
    name: 'Chicken Seekh Kebab (6 pc)',
    price: 229,
    priceDisplay: '₹229 onwards',
    category: 'kebabs',
    description: 'Juicy, melt-in-the-mouth minced chicken skewers blended with roasted cumin, green chillies & fresh coriander, charred in tandoor.',
    isVeg: false,
    image: 'https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=700&q=80',
    rating: '4.9',
    votes: 62,
    bestseller: true,
    serves: '6 Pieces'
  },
  {
    id: 'kebab-tikka',
    name: 'Chicken Tikka (6 pc)',
    price: 219,
    priceDisplay: '₹219 onwards',
    category: 'kebabs',
    description: 'Boneless chicken thighs marinated overnight in hung curd, Kashmiri deghi mirch and mustard oil, grilled over red hot embers.',
    isVeg: false,
    image: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=700&q=80',
    rating: '4.8',
    votes: 51,
    bestseller: true,
    serves: '6 Pieces'
  },
  {
    id: 'kebab-paneer-tikka',
    name: 'Paneer Tikka (6 pc)',
    price: 199,
    priceDisplay: '₹199 onwards',
    category: 'kebabs',
    description: 'Plump malai paneer cubes tossed in ajwain-spiced yogurt marinade with crunchy bell peppers and sweet onions, clay-oven roasted.',
    isVeg: true,
    image: 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?auto=format&fit=crop&w=700&q=80',
    rating: '4.7',
    votes: 39,
    serves: '6 Pieces'
  },
  {
    id: 'kebab-tandoori-momos',
    name: 'Tandoori Momos (8 pc)',
    price: 149,
    priceDisplay: '₹149 onwards',
    category: 'kebabs',
    description: 'Steamed dumplings coated in fiery red tandoori marinade, roasted crisp in charcoal oven and served with spicy schezwan dip & mint mayo.',
    isVeg: true,
    image: 'https://images.unsplash.com/photo-1625398407796-82650a8c135f?auto=format&fit=crop&w=700&q=80',
    rating: '4.9',
    votes: 73,
    bestseller: true,
    serves: '8 Pieces',
    customizable: true
  },

  // Chinese
  {
    id: 'chinese-hakka-noodles',
    name: 'Hakka Noodles (Veg/Chicken)',
    price: 179,
    priceDisplay: '₹179 onwards',
    category: 'chinese',
    description: 'Wok-tossed long wheat noodles seasoned with scallions, shredded cabbage, julienned capsicum, dark soya and toasted garlic.',
    isVeg: null,
    image: 'https://images.unsplash.com/photo-1585032226651-759b368d7246?auto=format&fit=crop&w=700&q=80',
    rating: '4.8',
    votes: 68,
    bestseller: true,
    customizable: true
  },
  {
    id: 'chinese-fried-rice',
    name: 'Fried Rice (Veg/Chicken)',
    price: 169,
    priceDisplay: '₹169 onwards',
    category: 'chinese',
    description: 'Fluffy wok-charred rice loaded with finely diced vegetables, garlic butter, and oriental spices in street stall Indo-Chinese style.',
    isVeg: null,
    image: 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?auto=format&fit=crop&w=700&q=80',
    rating: '4.6',
    votes: 44,
    customizable: true
  },
  {
    id: 'chinese-chilli-chicken',
    name: 'Chilli Chicken (8 pc)',
    price: 239,
    priceDisplay: '₹239 onwards',
    category: 'chinese',
    description: 'Batter fried chicken chunks tossed in spicy green chilli garlic sauce with crunchy onions and capsicum.',
    isVeg: false,
    image: 'https://images.unsplash.com/photo-1525755662778-989d0524087e?auto=format&fit=crop&w=700&q=80',
    rating: '4.9',
    votes: 59,
    bestseller: true,
    serves: '8 Pieces'
  },
  {
    id: 'chinese-manchurian',
    name: 'Veg Manchurian',
    price: 189,
    priceDisplay: '₹189 onwards',
    category: 'chinese',
    description: 'Golden fried vegetable dumplings simmered in rich sweet and savory dark soya coriander garlic gravy.',
    isVeg: true,
    image: 'https://images.unsplash.com/photo-1569058242253-92a9c755a0ec?auto=format&fit=crop&w=700&q=80',
    rating: '4.6',
    votes: 34
  },

  // Burgers & Sandwiches
  {
    id: 'burger-crispy-chicken',
    name: 'Crispy Chicken Burger',
    price: 149,
    priceDisplay: '₹149',
    category: 'burgers',
    description: 'Ultra-crunchy crumb-coated chicken breast patty topped with melted cheddar, crunchy iceberg lettuce & house creamy pepper sauce.',
    isVeg: false,
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=700&q=80',
    rating: '4.8',
    votes: 53,
    bestseller: true
  },
  {
    id: 'burger-veggie-crunch',
    name: 'Veggie Crunch Burger',
    price: 99,
    priceDisplay: '₹99',
    category: 'burgers',
    description: 'Crispy potato-peas herb patty with fresh tomato slices, crunchy onion rings, sliced cheese and zesty thousand island dressing.',
    isVeg: true,
    image: 'https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=700&q=80',
    rating: '4.5',
    votes: 41
  },
  {
    id: 'sandwich-grilled-veg',
    name: 'Grilled Veg Sandwich',
    price: 129,
    priceDisplay: '₹129',
    category: 'burgers',
    description: 'Three-layer butter toasted jumbo bread stuffed with mint chutney, cucumber, spiced mashed potato, tomato & melted mozzarella.',
    isVeg: true,
    image: 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=700&q=80',
    rating: '4.6',
    votes: 30
  },
  {
    id: 'sandwich-chicken-club',
    name: 'Club Sandwich (Chicken)',
    price: 149,
    priceDisplay: '₹149',
    category: 'burgers',
    description: 'Double-decker toasted artisan sandwich packed with seasoned chicken shreds, fried egg, cheese slice, lettuce and garlic mayo.',
    isVeg: false,
    image: 'https://images.unsplash.com/photo-1553909489-cd47e0907980?auto=format&fit=crop&w=700&q=80',
    rating: '4.7',
    votes: 38
  },

  // Pizza & Pasta
  {
    id: 'pizza-margherita',
    name: 'Margherita Pizza (10")',
    price: 199,
    priceDisplay: '₹199',
    category: 'pizza-pasta',
    description: 'Fresh hand-stretched thin crust stone-baked with Italian herb tomato concasse, generous mozzarella cheese & basil leaves.',
    isVeg: true,
    image: 'https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?auto=format&fit=crop&w=700&q=80',
    rating: '4.6',
    votes: 42
  },
  {
    id: 'pizza-corn-cheese',
    name: 'Corn & Cheese Pizza (10")',
    price: 229,
    priceDisplay: '₹229',
    category: 'pizza-pasta',
    description: 'Loaded with juicy sweet American golden corn, double mozzarella cheese, oregano seasoning and chilli flakes on crisp crust.',
    isVeg: true,
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=700&q=80',
    rating: '4.7',
    votes: 35
  },
  {
    id: 'pasta-white-sauce',
    name: 'White Sauce Pasta',
    price: 189,
    priceDisplay: '₹189',
    category: 'pizza-pasta',
    description: 'Penne pasta tossed in velvety garlic-infused rich bechamel cheese sauce with sauteed bell peppers, sweet corn & black olives.',
    isVeg: true,
    image: 'https://images.unsplash.com/photo-1621996346565-e3d5d6281292?auto=format&fit=crop&w=700&q=80',
    rating: '4.8',
    votes: 48,
    bestseller: true
  },
  {
    id: 'pasta-red-sauce',
    name: 'Red Sauce Pasta',
    price: 179,
    priceDisplay: '₹179',
    category: 'pizza-pasta',
    description: 'Al dente penne bathed in tangy, slow-simmered arrabbiata tomato sauce with basil, crushed red chilli flakes and parmesan shavings.',
    isVeg: true,
    image: 'https://images.unsplash.com/photo-1551183053-bf91a1d81141?auto=format&fit=crop&w=700&q=80',
    rating: '4.5',
    votes: 27
  },

  // Momos
  {
    id: 'momos-steamed-veg',
    name: 'Steamed Veg Momos (8 pc)',
    price: 99,
    priceDisplay: '₹99',
    category: 'momos',
    description: 'Translucent steamed Tibetan dumplings packed with finely minced cabbage, carrots, spring onions and ginger, paired with fiery red chilli chutney.',
    isVeg: true,
    image: 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&w=700&q=80',
    rating: '4.7',
    votes: 66,
    serves: '8 Pieces'
  },
  {
    id: 'momos-fried-chicken',
    name: 'Fried Chicken Momos (8 pc)',
    price: 149,
    priceDisplay: '₹149',
    category: 'momos',
    description: 'Crispy golden fried dumplings loaded with juicy spiced minced chicken filling. Crunchy outside, succulent inside.',
    isVeg: false,
    image: 'https://images.unsplash.com/photo-1496116218417-1a781b1c416c?auto=format&fit=crop&w=700&q=80',
    rating: '4.8',
    votes: 58,
    bestseller: true,
    serves: '8 Pieces'
  },
  {
    id: 'momos-tandoori',
    name: 'Tandoori Momos (8 pc)',
    price: 149,
    priceDisplay: '₹149',
    category: 'momos',
    description: 'Signature charcoal roasted momos dipped in spicy creamy tikka sauce, served with mint dip & onion rings.',
    isVeg: true,
    image: 'https://images.unsplash.com/photo-1625398407796-82650a8c135f?auto=format&fit=crop&w=700&q=80',
    rating: '4.9',
    votes: 75,
    bestseller: true,
    serves: '8 Pieces'
  },

  // Shakes & Beverages
  {
    id: 'bev-cold-coffee',
    name: 'Cold Coffee',
    price: 129,
    priceDisplay: '₹129',
    category: 'beverages',
    description: 'Thick, creamy blend of roasted espresso, whole milk, chilled vanilla ice cream and rich chocolate fudge swirl.',
    isVeg: true,
    image: 'https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?auto=format&fit=crop&w=700&q=80',
    rating: '4.8',
    votes: 60,
    bestseller: true
  },
  {
    id: 'bev-oreo-shake',
    name: 'Oreo Crunch Shake',
    price: 149,
    priceDisplay: '₹149',
    category: 'beverages',
    description: 'Decadent milkshake made with crushed crunchy Oreo cookies, premium dark chocolate sauce and whipped cream drizzle.',
    isVeg: true,
    image: 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&w=700&q=80',
    rating: '4.7',
    votes: 43
  },
  {
    id: 'bev-mango-shake',
    name: 'Mango Shake (seasonal)',
    price: 139,
    priceDisplay: '₹139',
    category: 'beverages',
    description: 'Rich, luscious shake crafted from sweet Alphonso mango pulp, condensed milk and garnished with chopped nuts.',
    isVeg: true,
    image: 'https://images.unsplash.com/photo-1546173159-315724a31696?auto=format&fit=crop&w=700&q=80',
    rating: '4.6',
    votes: 31
  },
  {
    id: 'bev-sweet-lassi',
    name: 'Sweet Lassi',
    price: 99,
    priceDisplay: '₹99',
    category: 'beverages',
    description: 'Traditional Punjabi thick sweetened churned curd lassi served chilled with a layer of fresh malai and cardamom essence.',
    isVeg: true,
    image: 'https://images.unsplash.com/photo-1528825871115-3581a5387919?auto=format&fit=crop&w=700&q=80',
    rating: '4.7',
    votes: 29
  },
  {
    id: 'bev-cappuccino',
    name: 'Cappuccino',
    price: 99,
    priceDisplay: '₹99',
    category: 'beverages',
    description: 'Hot freshly ground Arabica espresso shot crowned with velvety steamed milk foam and light cinnamon dusting.',
    isVeg: true,
    image: 'https://images.unsplash.com/photo-1534778101976-62847782c213?auto=format&fit=crop&w=700&q=80',
    rating: '4.5',
    votes: 24
  },
  {
    id: 'bev-masala-chai',
    name: 'Masala Chai (kulhad)',
    price: 49,
    priceDisplay: '₹49',
    category: 'beverages',
    description: 'Steaming hot kadak chai brewed with crushed ginger, green cardamom, cloves and served in an authentic earthen clay kulhad.',
    isVeg: true,
    image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=700&q=80',
    rating: '4.9',
    votes: 82,
    bestseller: true
  },

  // Desserts
  {
    id: 'des-brownie',
    name: 'Brownie with Ice Cream',
    price: 149,
    priceDisplay: '₹149',
    category: 'desserts',
    description: 'Warm, gooey dark chocolate walnut brownie served sizzling with a cold scoop of vanilla ice cream & warm chocolate ganache.',
    isVeg: true,
    image: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=700&q=80',
    rating: '4.9',
    votes: 52,
    bestseller: true
  },
  {
    id: 'des-gulab-jamun',
    name: 'Gulab Jamun (4 pc)',
    price: 99,
    priceDisplay: '₹99',
    category: 'desserts',
    description: 'Warm melt-in-mouth golden khoya dumplings soaked in rose water and cardamom sugar syrup.',
    isVeg: true,
    image: 'https://images.unsplash.com/photo-1593701461250-d7b22dfd3a77?auto=format&fit=crop&w=700&q=80',
    rating: '4.7',
    votes: 37,
    serves: '4 Pieces'
  },
  {
    id: 'des-ice-cream',
    name: 'Ice Cream Scoop',
    price: 79,
    priceDisplay: '₹79',
    category: 'desserts',
    description: 'Creamy premium ice cream scoop of your choice (Rich Vanilla, Belgian Chocolate, or Alphonso Mango).',
    isVeg: true,
    image: 'https://images.unsplash.com/photo-1560008581-09826d1de69e?auto=format&fit=crop&w=700&q=80',
    rating: '4.5',
    votes: 22
  }
];

export const CATEGORIES_LIST = [
  { id: 'bestsellers', name: 'Bestsellers', count: 9, img: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=300&q=80' },
  { id: 'biryani', name: 'Biryani', count: 4, img: 'https://images.unsplash.com/photo-1633945274405-b6c8069047b0?auto=format&fit=crop&w=300&q=80' },
  { id: 'kebabs', name: 'Kebabs', count: 4, img: 'https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=300&q=80' },
  { id: 'chinese', name: 'Chinese', count: 4, img: 'https://images.unsplash.com/photo-1585032226651-759b368d7246?auto=format&fit=crop&w=300&q=80' },
  { id: 'burgers', name: 'Burgers', count: 4, img: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=300&q=80' },
  { id: 'pizza-pasta', name: 'Pizza & Pasta', count: 4, img: 'https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?auto=format&fit=crop&w=300&q=80' },
  { id: 'momos', name: 'Momos', count: 3, img: 'https://images.unsplash.com/photo-1625398407796-82650a8c135f?auto=format&fit=crop&w=300&q=80' },
  { id: 'beverages', name: 'Beverages', count: 6, img: 'https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?auto=format&fit=crop&w=300&q=80' },
  { id: 'desserts', name: 'Desserts', count: 3, img: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=300&q=80' }
];

export const REVIEWS_LIST: Review[] = [
  {
    author: 'Anaya T.',
    rating: 5,
    comment: 'Amazing vibe and excellent service. Tastiest food at such cheap prices, must visit!',
    date: '3 days ago',
    helpfulCount: 14
  },
  {
    author: 'Rashmi K.',
    rating: 5,
    comment: 'Awesome hangout place for couples, friends and families. Super delicious biryani, quick service, pocket friendly prices.',
    date: '1 week ago',
    helpfulCount: 19
  },
  {
    author: 'Anmol',
    rating: 5,
    comment: 'Tried the veg keema biryani, absolutely delightful. Cozy atmosphere, must-visit spot.',
    date: '2 weeks ago',
    helpfulCount: 11
  }
];

export const PHOTO_GALLERY = [
  {
    url: 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=900&q=80',
    title: 'Cafe Warm Ambience & Hangout'
  },
  {
    url: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=900&q=80',
    title: 'Hyderabadi Matka Biryani'
  },
  {
    url: 'https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=900&q=80',
    title: 'Charcoal Grilled Seekh Kebabs'
  },
  {
    url: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=900&q=80',
    title: 'Cozy Friends Adda Seating'
  },
  {
    url: 'https://images.unsplash.com/photo-1585032226651-759b368d7246?auto=format&fit=crop&w=900&q=80',
    title: 'Wok-Tossed Street Hakka Noodles'
  },
  {
    url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=900&q=80',
    title: 'Crispy Gourmet Chicken Burger'
  }
];
